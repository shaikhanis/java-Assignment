package function;
import java.util.*;
public class palindromNumber {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int sum, palindrome = 0;
         int num = n;
        while (n>0){
            sum = n%10;
            n=n/10;
            palindrome = (palindrome*10) +sum;
        }
          System.out.println(palindrome);

        if (num==palindrome){
            System.out.println(" Given Number N is Palindrome Number");

        }else {
            System.out.println(" NOT Number is not palindrome");
            System.out.println(palindrome);
        }
    }
}
