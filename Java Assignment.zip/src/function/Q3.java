package function;
import java.util.*;
public class Q3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        boolean isInArray = false;
        int [] mark = {50,60,80,50,90,30,};
        for(int number : mark){

            if(num==number){
                isInArray = true;
                break;
            }
        }
        if(isInArray){
            System.out.println("number is in Array");
        }else {
            System.out.println("is NOT In Array");
        }
    }
}
