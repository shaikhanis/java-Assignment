package function;
import java.util.*;
public class primeNumber1To100 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int i,j;
        int count = 0;
        for(i = 1; i<=n; i++){
            for(j =2; j<=i; j++){
                if(i%j==0)
                    break;
            }
            if(i==j) {
                int sum = count+j;
                System.out.print(j+"  ");
            }
        }
    }
}

