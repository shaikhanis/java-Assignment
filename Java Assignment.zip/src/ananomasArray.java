public class ananomasArray {
    public static void main(String[] args) {
 //       ananomasArray.sum(new int []{25,26,27,82});

    }
//    static void sum (int[]no){
//        int totle = 0;
//        for(int i : no){
//            totle = totle+i;
//        }
//        System.out.println("sum is : "+totle);
//    }

}
