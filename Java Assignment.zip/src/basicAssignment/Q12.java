package basicAssignment;
import java.util.*;
public class Q12 {
    public static void main(String[] args) {
        /* Problem statement.
        WAP to generate Fibonacci series in forward and reverse order. Take number of terms to print from
console. Series for 8 terms will be as follows : 0, 1, 1, 2,3,5,8,13 and 13,8,5,3,2,1,1,0
         */
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Your Number How long You Print The Series");
        int n = sc.nextInt();
        int a =1,b = 0, c;
        System.out.print("            The fibonacci Series is  ");
        for(int i = 1; i<n; i++){
            System.out.print(b+"  ");
            c = a+b;
            a = b;
            b = c;
        }
        System.out.println(" ");
        System.out.print(" The revers fibonacci series is ");
        for(int i = 0; i<n; i++){
            System.out.print(b+"  ");
            c = b-a;
            b = a;
            a = c;
        }

    }
}
