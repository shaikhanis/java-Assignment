package basicAssignment;
import java .util.*;
public class Q7 {
    public static void main(String[] args) {
        /* Problem Statement.
         * * * * *
         * * * *
         * * *
         * *
         *
    */
        Scanner sc = new Scanner(System.in);
        System.out.println("enter your number");

        int n = sc.nextInt();
        for (int i = 1; i<=n; i++){
            for (int j =1; j<=n-i+1; j++){
                System.out.print("* ");
            }
            System.out.println();
        }
        
    }

}
