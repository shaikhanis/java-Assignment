package basicAssignment;
import java .util.*;
public class Q3 {
    public static void main(String[] args) {
        /*Problem Statement.
        A student will not be allowed to sit the exam if the attendance is less than 70%.
        input
        1. number of class hold.
        2. number of class attend.
        and print the student id sit for exam or not.
         */
        Scanner sc = new Scanner(System.in);
        double percentage = 0;
        System.out.println("Please Enter the class hold ");
        double totalclass = sc.nextDouble();
        System.out.println("Please Enter the atended class ");
        double atendclass = sc.nextDouble();

        percentage = (atendclass*100)/totalclass;
        if (percentage>=70){
            System.out.println("student are sit in exam "+ percentage);
        }else{
            System.out.println("student are not sit in exam "+ percentage);
        }
    }
}
