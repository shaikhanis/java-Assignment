package basicAssignment;
import java .util.*;
public class Q9 {
    public static void main(String[] args) {
        /* Problem Statement.
         Write a program to convert days into years, weeks and days.
 Write a program to convert days into years, weeks and days.
 Example
Input
Enter days: 1025
Output

1025 days = 2 year/s, 42 week/s and 1 day/s
         */
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter your days");
        int days = sc.nextInt();
        int years = (days /365);
        int weeks = (days %365)/7;
               days =(days %365)%7;

        System.out.println("Year/s = " + years);
        System.out.println("Week/s = " + weeks);
        System.out.println("Day/s  = " + days);
    }
}
