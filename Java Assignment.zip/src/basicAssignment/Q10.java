package basicAssignment;
import java.util.*;
public class Q10 {
    public static void main(String[] args) {


        Scanner sc = new Scanner(System.in);
    /* Problem Statement.
    What is ‘Compound interest’ ?
Compound interest is the addition of interest to the principal sum of a loan or deposit, or in other words, interest on interest. It is the result of reinvesting interest, rather than paying it out, so that interest in the next period is then earned on the principal sum plus previously-accumulated interest. Compound interest is standard in finance and economics.
Compound interest may be contrasted with simple interest, where interest is not added to the principal, so there is no compounding.
Compound Interest formula:


Formula: to calculate compound interest annually is given by:
Amount= P(1 + R/100)t

Compound Interest = Amount – P
Where,
P is the principal amount
R is the rate and
T is the time span
     */
        double p = sc.nextDouble();
        double r = sc.nextDouble();
        double t = sc.nextDouble();

        double amount = p*(Math.pow((1+r/100),t));
        double CI = amount - p;

        System.out.println("The compound Interest "+CI);
    }
}
