package basicAssignment;
import java.util.*;
public class Q5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        /* Problem statement
        Take the value of the length and breadth from the user and check this is a triangle or not
         */
        System.out.println("Please Enter Your Length");
        int length = sc.nextInt();
        System.out.println("Please Enter Your Breadth");
        int breadth = sc.nextInt();

        if (length == breadth){
            System.out.println("this is the square ");
        }else {
            System.out.println("this is rectangle");
        }
    }
}