package basicAssignment;
import java.util.*;
public class Q2 {
    public static void main(String[] args) {
        /* Problem Statement.
        A company is decided to give a bonus to of 10% to the employ if his / her year of service is more than 5 year.
        Ask for there salary and year of service and print the net bonus amount.
         */
        Scanner sc = new Scanner(System.in);
        double totalsalary = 0;
        double total = 0;
        System.out.println("Please Enter the Salary ");
        double salary = sc.nextDouble();
        System.out.println("Please Enter the year ");
        double year = sc.nextDouble();
        if (year > 5) {
            total = salary * 0.1;
            totalsalary = total + salary;
            System.out.println("the salary + bonus salary is " + totalsalary);
        } else {
            System.out.println("Salary without bonus "+salary);
        }
    }
}