package basicAssignment;
import java.util.*;
public class Q14 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();


        for (int i =1; i<=10; i++){
            int mul = a*i;
            System.out.println(mul);
        }
    }
}
