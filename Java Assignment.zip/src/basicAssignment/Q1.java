package basicAssignment;
import java.util.*;
public class Q1 {
    public static void main(String[] args) {
        /* problem Statement.
        A shop will give a discount of 20% if the cost of the purchaser quantity is more than 1500
        Ask the user for quantity.
        suppose one cost is 200, judge and print the total cost for the user.
         */
        Scanner sc = new Scanner(System.in);
        double unit = 200;
        double totle = 0;
        System.out.println("please enter the unit");
        double quantity = sc.nextDouble();
        totle = quantity*unit;
        System.out.println("totle cost is "+totle);
        if(totle>1500){
            totle = totle*20/100;
            System.out.println("totle discont is "+totle);
        }else{
            System.out.println("without Discount "+totle);
        }
    }
}
