package basicAssignment;
import java.util.*;
public class Q6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        /* Problem Statement.
        print the factorial
        ex factorial of 5 is 5*4*3*2*1 = 120
         */
//        System.out.println("please enter the number");
//        int n = sc.nextInt();
//        int fact = 1;
//        for (int i = 1; i<=n; i++){
//            fact = fact*i;
//        }
//        System.out.println("the factorial of given number is  "+"factorial = "+fact);

//           #Using while loop #

        System.out.println("please enter the number");
        int n = sc.nextInt();
        int fact = 1;
        int i = 1;
        while (i<=n){
            fact = fact*i;
            i++;
        }
        System.out.println("the factorial of given number is  "+"factorial = "+fact);
    }
}
