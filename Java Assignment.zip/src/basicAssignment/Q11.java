package basicAssignment;
import java.util.*;
public class Q11 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        /* Problem Statement.
        Write a program to calculate area of an equilateral triangle.
         Formula for triangle is (√ 3 / 4) * side * side ,
         that means √ 3 = 1.7320
         */
        System.out.println("Please Enter The Sides of the Triangle");
        float a = s.nextFloat();
        float area = (float) (1.7320/4)*a*a;
        System.out.println("The area of triangle is "+area);

    }
}
