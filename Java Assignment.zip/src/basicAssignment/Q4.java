package basicAssignment;
import java.util.*;
public class Q4 {
    public static void main(String[] args) {
        /* Problem Statement.
        Take input of the Age of 3 people by the user and determine the older and younger among them.
        */
        Scanner sc = new Scanner(System.in);
        System.out.println("Age of people A");
        int a = sc.nextInt();
        System.out.println("Age of people B");
        int b = sc.nextInt();
        System.out.println("Age of people C");
        int c = sc.nextInt();

        if(a>b && a>c){
            System.out.println("A is oldest");
        }
        else if (a<b && a<c){
            System.out.println("B is oldest");
        }
        else{
            System.out.println("C is oldest");
        }
        if(a<b && a<c){
            System.out.println("A is youngest");
        }
        else if (b<a && b<c){
            System.out.println("B is youngest");
        }else{
            System.out.println("C is youngest");
        }
    }
}
