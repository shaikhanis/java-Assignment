package basicAssignment;

import java.util.Scanner;

public class Switch_Statement {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String yn;
        do {
            System.out.println("enter num 1");
            int num1 = sc.nextInt();
            System.out.println("enter num 2");
            int num2 = sc.nextInt();
            int result;
            System.out.println("inter(+,-,/,*)");
            String oprater = sc.next();
            switch (oprater) {
                case "+" -> {
                    result = num1 + num2;
                    System.out.println(result);
                }
                case "-" -> {
                    result = num1 - num2;
                    System.out.println(result);
                }
                case "*" -> {
                    result = num1 * num2;
                    System.out.println(result);
                }
                case "/" -> {
                    result = num1 / num2;
                    System.out.println(result);
                }
                default -> System.out.println("invalid oprater");
            }

            System.out.println("do you want to continue press yes or no");
            yn = sc.next();
        }        while ((yn.equals("y"))||(yn.equals("Y")));
    }
}
