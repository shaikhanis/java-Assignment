package basicAssignment;
import java.util.Scanner;
public class primeNumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        /*
        fot prime
        for(int i= 1; i<=n; i++){
           if(n%i==0){
             count = count + 1;
           }
           if(count == 2){
              System.out.print(" isPrime");
           }
        }
         */

        int j,i;
        int count = 0;
        int n1 = sc.nextInt();
        int n2 = sc.nextInt();
        for(i = n1; i <n2; i++){
            for(j = 2; j<i; j++){
                if(i%j == 0){
                    break;
                }
            }
            if(i==j){
                System.out.print(j+" ");
                count = count+1;
            }
        }
        System.out.println();
        System.out.println("count is "+count);

    }
}