package com.company;
import java.util.*;
public class Loops {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);

        int n  = scn.nextInt();

        for(int i = 1; i< 11; i = i + 1){

            System.out.println(i * n);
        }
    }
}
