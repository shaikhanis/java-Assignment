package com.company;

public class addNumber {
    public static void main(String[] args)
    {
        int num=10,sum=0;
        for(int i =0; i<=num; i++)
        {
          sum = sum+i;
          System.out.println(" "+i);
        }
        System.out.println("Sum of Numbers ="+sum);
    }
}
