package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class javaArrays {
    public static void main(String[] args) {
//        int a [] = new int [5];
//        System.out.println("Enter your Array Element");
//        Scanner s = new Scanner(System.in);
//        for(int i=0; i<5; i++){
//            a[i]= s.nextInt();
//        }
//        Arrays.sort(a);
//        System.out.println("Array Element");
//        for(int b : a){
//
//            System.out.println(b+" ");
//        }

    }
}
