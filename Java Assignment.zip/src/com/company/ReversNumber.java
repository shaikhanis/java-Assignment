package com.company;
import java.util.*;
public class ReversNumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("inter your number");
        int num = sc.nextInt();

        int sum = 0;
        int count = 0;
        while(num>0) {
            int lastdigit = num % 10;
            num = num / 10;
            count = lastdigit*10;

        }
        System.out.println(count);
    }
}
