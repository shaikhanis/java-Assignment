import java.util.Scanner;

public class QuickSortMiddle {
    public static void main(String[] args) {

    }
}