package javaRecursion;

public class fibonacci {
    public static void main(String[] args) {
        int a = 0;
        int b = 1;
        int n = 8;
        System.out.print(a+" ");
        System.out.print(b+" ");
        fibbo(a,b,n-2);
    }

    static void fibbo(int a, int b, int n) {
        if (n==0){
            return;
        }
        int c = a+b;
        System.out.print(c+" ");
        fibbo(b,c,n-1);
    }
}