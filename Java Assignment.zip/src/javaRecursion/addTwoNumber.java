package javaRecursion;
import java.util.*;
public class addTwoNumber {
    public static int sum(int x, int n){
        if (n==0){
            return 1;
        }
        if (x==0){
            return 0;
        }
        int num = sum(x,n-1);
        return x*num;
    }

    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        System.out.println("Enter your number");
        int x = sc.nextInt();
        int n = sc.nextInt();
        System.out.println(sum(x,n));
//        int power = 1;
//        for(int i=1; i<=n; i++){
//             power = x*power;

    }
}