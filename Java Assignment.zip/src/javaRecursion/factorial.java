package javaRecursion;

public class factorial {

    int fac=1;
    int fact (int no){
        if(no>1){
            fac = fac*no;
            fact(no-1);
        }return fac;
    }

    public static void main(String[] args) {
        int no = 5;
        factorial f= new factorial();
        int res = f.fact(no);
        System.out.println(res);
    }
}
