package ApnaCollege;

import java.util.Scanner;
public class Circumference {
    public static double GetCircumference(double radius) {
        return 2 * 3.14 * radius;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Entre Your Radius");
        double radius = sc.nextDouble();
        System.out.println(GetCircumference(radius));
    }
}
