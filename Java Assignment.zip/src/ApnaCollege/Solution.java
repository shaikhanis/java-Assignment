package ApnaCollege;
import java.util.*;
public class Solution {
    public static void main(String[] args) {
        System.out.println("Enter The Value Of X");
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        System.out.println("Enter The Value Of n");
        int n = sc.nextInt();
        int result = 1;
        for(int i = 1; i<=n; i++){
            result = result*x;
        }
        System.out.println(result);
    }
}
