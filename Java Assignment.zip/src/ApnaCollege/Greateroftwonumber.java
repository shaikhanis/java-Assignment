package ApnaCollege;

import java.util.Scanner;

public class Greateroftwonumber {
    public static void GreaterNumber(int a, int b) {
        System.out.print(Math.max(a, b));
}

    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter your Numbers");
    int a = sc.nextInt();
    int b = sc.nextInt();
    GreaterNumber(a,b);
    }
}