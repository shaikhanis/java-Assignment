package ApnaCollege;
import java.util.*;
public class Eligibleforvote {
    public static void isElligible(int age){
        if(age>=18){
            System.out.println("is Elligible for vote");
        }else{
            System.out.println("not Elligible for vote");
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Your Age");
        int age = sc.nextInt();
        isElligible(age);
    }
}
