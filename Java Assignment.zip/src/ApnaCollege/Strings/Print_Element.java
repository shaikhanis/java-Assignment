package ApnaCollege.Strings;
import java.util.*;
public class Print_Element {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        System.out.println("Please Enter the size of arr");
        int size = sc.nextInt();
        String [] arr = new String[size];
        System.out.println("please enter the arr");
        int totle = 0;
        for (int i = 0; i<size; i++) {
            arr[i] = sc.nextLine();
            totle = totle+ arr[i].length();

        }
        System.out.println("totle length of arr"+totle);
//        for(int i =0; i<arr.length; i++);
  //      System.out.println(arr.length);
    }
}
