package ApnaCollege.Strings;
import java. util.*;
public class Strings_builder {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
//        Dclearation of String Bulder
//        StringBuilder sb  = new StringBuilder("Saajan");
//        System.out.println(sb);
//        System.out.println(sb.charAt(2));
//        sb.setCharAt(0 , 'p');
//        System.out.println(sb);
//        sb.insert(6,'c');
//        sb.delete(2,3);
//        sb.append('c');
//        System.out.println(sb);

        //solve revers string

    }
}
