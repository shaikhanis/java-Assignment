package ApnaCollege.Strings;

import java.util.Scanner;
import java.util.concurrent.SubmissionPublisher;

public class Strings {
    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        System.out.println("lease Enter Your String");
//        String a = sc.nextLine();
//        String b= sc.nextLine();
//
//        if(a.compareTo(b) == 0){
//            System.out.println("Strings Are Equal");
//        }else{
//            System.out.println("Strings Are Not Equal");
//        }
        String sentence = ("My Name Is Rahul");
        String a = sentence.substring(1,5);
        System.out.println(a);
    }
}
