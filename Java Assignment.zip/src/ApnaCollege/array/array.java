package ApnaCollege.array;

public class array {
    public static void main(String[] args) {
        int[] marks = new int[3];
        marks[0] = 55;
        marks[1] = 85;
        marks[2] = 94;
//        System.out.println(marks[0]);
//        System.out.println(marks[1]);
//        System.out.println(marks[2]);

        for(int i = 0; i<3; i++){

            System.out.println(marks[i]);


        }
    }
}
