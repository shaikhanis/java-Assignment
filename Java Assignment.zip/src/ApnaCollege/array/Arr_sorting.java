package ApnaCollege.array;
import java.util.*;
public class Arr_sorting {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        System.out.println("Enter Arr size");
        int size = sc.nextInt();
        int [] numbers = new int[size];
        for(int i = 0; i<size; i++){
            numbers[i] = sc.nextInt();
        }
        boolean isAscending = true;

        for(int i = 0; i<numbers.length-1; i++){
            if (numbers[i] > numbers[i + 1]) {
                isAscending = false;
                break;
            }
        }
        if(isAscending){
            System.out.println("This Arr is sorting Ascending order");
        }else{
            System.out.println("This Arr is not Sorted");
        }
    }
}
