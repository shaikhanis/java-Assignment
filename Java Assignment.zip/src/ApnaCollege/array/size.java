package ApnaCollege.array;

public class size {
    public static void main(String[] args) {
        int c = 0;
        for( int i =1; i<=10; i++){

            c = c+1;

        }
        System.out.println(c);
    }
}

