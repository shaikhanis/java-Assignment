package ApnaCollege.array;
import java.util.*;
public class Arrelement {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);

        System.out.println("Please Enter the size of arr");

        int size =  sc.nextInt();

        int [] numbers  = new int[size];

        System.out.println("Please Enter the numbers  of arr");

        for(int i = 0; i<size; i++){

             numbers[i] = sc.nextInt();

        }
        System.out.println(Arrays.toString(numbers));
    }
}
