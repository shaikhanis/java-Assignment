import java.util.StringJoiner;
public class stringJoiner {
    public static void main(String[] args) {
        StringJoiner sj1 = new StringJoiner(",","[","]");
        sj1.add("a").add("b").add("c");
        System.out.println(sj1);

        StringJoiner sj2 = new StringJoiner(":");
        sj2.add("p").add("q");
        System.out.println(sj2);
        sj1.merge(sj2);
        System.out.print(sj1);
    }

}
